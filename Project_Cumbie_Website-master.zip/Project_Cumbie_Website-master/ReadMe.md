# Cumbies Website

A centralized  location that offers the continuation of project managment stackholders. 
![](header.png)

## Project Information 

Duration: 10 weeks - October 3, 2018 to December 5, 2018

Client: Dr. Barry Cumbie

## Project Manager

* David Barrett


## Project Objectives

* House all system files in a central repository with configuration instructions.
* House all project files accessible from the same system repository.
> “Make your project matter by making it repeatable"

## Development 

```sh
This project was designed using the c9 workstsation HTML engine. Using the Bootstrap foundation
for Responsive development, was the choice when designing. GitHub is hosting the file structure 
as a repository and the URL is (<https://github.com/xXHoudiniXx/cumbie-website.git>). 
This is where to request a pull from the master branch. All projects will be stored on 
google Docs, but will be linked inside the HTML of the project. The project folder can
be accessible in the startbootstrap folder. 
```
## Version Changes

```sh
While the objective is to update the version of this project, please mind the CHANGELOG.md
file in the root directory. Please utilize this and push it to your forked branch.
```


## META

```sh
Please see the Project Chater chapter 6.0, in the Projects Doc folder, for all Acknowledgments 
```

## Contributing with git

*Fork it (<https://github.com/xXHoudiniXx/cumbie-website.git>)
*Create your feature branch (`git checkout -b feature/fooBar`)
*Commit Changes(`git checkout -b feature/fooBar`)
*Push to branch (`git push origin feature/fooBar)
*Create pull request

